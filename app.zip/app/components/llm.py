from langchain_huggingface import HuggingFaceEndpoint
from app.config.config import HF_token, HUGGINGFACE_REPO_ID

from app.common.logger import get_logger
from app.common.custom_exception import CustomException

logger = get_logger(__name__)

def load_llm(huggingface_repo_id: str = HUGGINGFACE_REPO_ID, hf_token: str = HF_token):
    try:
        logger.info("loading LLM from Hugging Face...")

        llm = HuggingFaceEndpoint(
            repo_id = huggingface_repo_id,
            huggingface_hub_api_token=hf_token,
            temperature = 0.1,  
            max_length = 256,
            return_full_text = False,
        )

        logger.info("LLM loaded successfully.")

        return llm
    
    except Exception as e:
        error_message = CustomException("Failed to load LLM from Hugging Face", e)
        logger.error(str(error_message))